// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";
import { div } from "framer-motion/client";

const Navbar = () => {
  return (
    <div>
      Navbar
    </div>
  );
};

export default Navbar;
