// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";

const Hero = () => {
  return (
    // <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0b0014] via-[#1a0033] to-[#2a004d] text-white">
    //   <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-10 items-center">
    //     {/* LEFT CONTENT */}
    //     <motion.div
    //       initial={{ x: -80, opacity: 0 }}
    //       animate={{ x: 0, opacity: 1 }}
    //       transition={{ duration: 1 }}
    //     >
    //       <h1 className="text-4xl md:text-5xl font-bold leading-tight">
    //         Hi, I’m <span className="text-purple-400">Sucharita</span>
    //       </h1>

    //       <h2 className="text-xl md:text-2xl mt-4 text-purple-300">
    //         Frontend Developer
    //       </h2>

    //       <p className="mt-6 text-gray-400 max-w-md">
    //         Crafting modern, responsive, and user-friendly websites with passion
    //         and precision.
    //       </p>

    //       <button className="mt-8 px-6 py-3 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:scale-105 transition">
    //         Download Resume
    //       </button>
    //     </motion.div>

    //     {/* RIGHT IMAGE */}
    //     <motion.div
    //       initial={{ scale: 0.8, opacity: 0 }}
    //       animate={{ scale: 1, opacity: 1 }}
    //       transition={{ duration: 1 }}
    //       className="flex justify-center"
    //     >
    //       <div className="w-64 h-64 rounded-full border-4 border-purple-500 overflow-hidden shadow-[0_0_60px_#a855f7]">
    //         <img
    //           src="/profile.png"
    //           alt="profile"
    //           className="w-full h-full object-cover"
    //         />
    //       </div>
    //     </motion.div>
    //   </div>
    // </section>
    <div>Hero</div>
  );
};

export default Hero;
