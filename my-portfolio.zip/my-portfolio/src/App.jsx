import React from "react";

const App = () => {
  return (
    <div>
      <div className="h-screen flex items-center justify-center bg-black">
        <h1 className="text-4xl font-bold text-black">
          Tailwind is Working 🚀
        </h1>
      </div>
    </div>
  );
};

export default App;
